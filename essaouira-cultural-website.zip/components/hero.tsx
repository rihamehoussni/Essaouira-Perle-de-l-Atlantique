export function Hero() {
  return (
    <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(/placeholder.svg?height=1080&width=1920&query=essaouira+beach+sunset+blue+boats)`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-primary/60 via-primary/40 to-background/90" />
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 text-balance">
          Essaouira
        </h1>
        <p className="text-xl md:text-2xl text-white/90 mb-8 text-pretty">{"La Perle de l'Atlantique"}</p>
        <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto text-pretty">
          Découvrez une ville fortifiée où l'histoire millénaire rencontre l'océan Atlantique, où les remparts blancs et
          bleus protègent un patrimoine culturel exceptionnel
        </p>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg
          className="w-6 h-6 text-white"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
        </svg>
      </div>
    </section>
  )
}
