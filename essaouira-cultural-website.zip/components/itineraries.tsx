import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, MapPin, TrendingUp } from "lucide-react"

interface Itinerary {
  id: string
  title: string
  duration: string
  difficulty: string
  description: string
  stops: string[]
  distance: string
}

const itineraries: Itinerary[] = [
  {
    id: "1",
    title: "Découverte Essentielle",
    duration: "1 jour",
    difficulty: "Facile",
    description: "Un circuit parfait pour une première visite, couvrant les sites incontournables d'Essaouira.",
    stops: [
      "Petit-déjeuner à la Place Moulay Hassan",
      "Visite de la Médina et ses souks",
      "Déjeuner de poisson frais au port",
      "Promenade sur les remparts",
      "Coucher de soleil sur la plage",
    ],
    distance: "5 km",
  },
  {
    id: "2",
    title: "Immersion Culturelle",
    duration: "2 jours",
    difficulty: "Modérée",
    description: "Plongez dans la richesse culturelle et artistique d'Essaouira avec ce circuit approfondi.",
    stops: [
      "Jour 1: Médina, souks et artisans",
      "Musée Sidi Mohammed ben Abdallah",
      "Galeries d'art contemporain",
      "Jour 2: Atelier de marqueterie",
      "Concert de musique gnaoua",
      "Dîner traditionnel en riad",
    ],
    distance: "8 km",
  },
  {
    id: "3",
    title: "Aventure Nature",
    duration: "3 jours",
    description: "Pour les amateurs de nature et de sports, découvrez Essaouira et ses environs.",
    difficulty: "Sportive",
    stops: [
      "Jour 1: Kitesurf sur la plage",
      "Observation de l'île de Mogador",
      "Jour 2: Excursion à cheval dans les dunes",
      "Visite des arganiers",
      "Jour 3: Quad dans les forêts de thuya",
      "Détente au hammam",
    ],
    distance: "45 km",
  },
]

export function Itineraries() {
  return (
    <section id="itineraries" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4">Itinéraires Suggérés</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Des circuits pensés pour explorer Essaouira selon vos envies et votre temps
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {itineraries.map((itinerary) => (
            <Card key={itinerary.id} className="p-6 hover:shadow-xl transition-shadow flex flex-col">
              <div className="mb-6">
                <h3 className="font-serif text-2xl font-bold mb-3 text-foreground">{itinerary.title}</h3>
                <p className="text-muted-foreground leading-relaxed mb-4">{itinerary.description}</p>
              </div>

              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center gap-2 text-sm bg-muted px-3 py-1.5 rounded-full">
                  <Clock className="w-4 h-4 text-accent" />
                  <span>{itinerary.duration}</span>
                </div>
                <div className="flex items-center gap-2 text-sm bg-muted px-3 py-1.5 rounded-full">
                  <TrendingUp className="w-4 h-4 text-accent" />
                  <span>{itinerary.difficulty}</span>
                </div>
                <div className="flex items-center gap-2 text-sm bg-muted px-3 py-1.5 rounded-full">
                  <MapPin className="w-4 h-4 text-accent" />
                  <span>{itinerary.distance}</span>
                </div>
              </div>

              <div className="flex-1 mb-6">
                <h4 className="font-semibold mb-3 text-foreground">Étapes du circuit :</h4>
                <ul className="space-y-2">
                  {itinerary.stops.map((stop, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-accent/20 text-accent flex items-center justify-center text-xs font-semibold mt-0.5">
                        {index + 1}
                      </span>
                      <span className="leading-relaxed">{stop}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Button className="w-full bg-primary hover:bg-accent text-primary-foreground">Voir les détails</Button>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-card p-8 rounded-lg shadow-md max-w-4xl mx-auto">
          <h3 className="font-serif text-2xl font-bold text-primary mb-4 text-center">Conseils pour Votre Visite</h3>
          <div className="grid md:grid-cols-2 gap-6 text-foreground/90">
            <div>
              <h4 className="font-semibold mb-2">Meilleure période</h4>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Avril à octobre pour le beau temps, juin pour le Festival Gnaoua
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Transport</h4>
              <p className="text-sm leading-relaxed text-muted-foreground">
                La médina se visite à pied, location de vélos disponible
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Hébergement</h4>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Riads traditionnels dans la médina ou hôtels en bord de mer
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Gastronomie</h4>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Poisson frais, tajine de poisson, pâtisseries aux amandes
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
