"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"

declare global {
  interface Window {
    L: any
  }
}

export function InteractiveMap() {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)

  useEffect(() => {
    if (typeof window === "undefined" || !mapRef.current) return

    const loadLeaflet = async () => {
      if (window.L && mapInstanceRef.current) return

      const script = document.createElement("script")
      script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
      script.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
      script.crossOrigin = ""

      script.onload = () => {
        if (mapInstanceRef.current) return

        const L = window.L
        const map = L.map(mapRef.current).setView([31.5125, -9.77], 14)

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: "© OpenStreetMap contributors",
          maxZoom: 19,
        }).addTo(map)

        const places = [
          { name: "La Médina", lat: 31.5125, lng: -9.77, desc: "Patrimoine UNESCO" },
          { name: "Les Remparts", lat: 31.5135, lng: -9.772, desc: "Fortifications historiques" },
          { name: "Le Port", lat: 31.508, lng: -9.768, desc: "Port de pêche" },
          { name: "Plage", lat: 31.505, lng: -9.78, desc: "Plage de sable fin" },
          { name: "Île de Mogador", lat: 31.495, lng: -9.79, desc: "Réserve naturelle" },
          { name: "Musée", lat: 31.513, lng: -9.769, desc: "Musée Sidi Mohammed" },
        ]

        const blueIcon = L.divIcon({
          className: "custom-marker",
          html: '<div style="background-color: #3b82f6; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>',
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        })

        places.forEach((place) => {
          L.marker([place.lat, place.lng], { icon: blueIcon })
            .addTo(map)
            .bindPopup(
              `<div style="font-family: sans-serif;"><strong style="color: #1e40af; font-size: 14px;">${place.name}</strong><br/><span style="color: #64748b; font-size: 12px;">${place.desc}</span></div>`,
            )
        })

        mapInstanceRef.current = map
      }

      document.head.appendChild(script)
    }

    loadLeaflet()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  return (
    <section id="map" className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4">Carte Interactive</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Explorez les lieux touristiques d'Essaouira sur notre carte interactive
          </p>
        </div>

        <Card className="overflow-hidden shadow-xl">
          <div ref={mapRef} className="w-full h-[500px] md:h-[600px]" style={{ background: "#e5e7eb" }} />
        </Card>

        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card className="p-6 bg-card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-6 h-6 rounded-full bg-primary" />
              <h3 className="font-semibold">Sites touristiques</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Cliquez sur les marqueurs pour voir les détails de chaque lieu
            </p>
          </Card>

          <Card className="p-6 bg-card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-6 h-6 rounded bg-accent" />
              <h3 className="font-semibold">Navigation</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Utilisez la molette pour zoomer et faites glisser pour vous déplacer
            </p>
          </Card>

          <Card className="p-6 bg-card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-6 h-6 rounded-full border-4 border-primary bg-white" />
              <h3 className="font-semibold">Géolocalisation</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Coordonnées GPS précises pour chaque point d'intérêt
            </p>
          </Card>
        </div>
      </div>
    </section>
  )
}
