"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: "smooth" })
    setIsOpen(false)
  }

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-card/95 backdrop-blur-md shadow-md" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={() => scrollToSection("hero")}
            className="font-serif text-2xl font-bold text-primary hover:text-accent transition-colors"
          >
            Essaouira
          </button>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection("about")}
              className="text-foreground/80 hover:text-primary transition-colors"
            >
              Histoire
            </button>
            <button
              onClick={() => scrollToSection("places")}
              className="text-foreground/80 hover:text-primary transition-colors"
            >
              Lieux
            </button>
            <button
              onClick={() => scrollToSection("itineraries")}
              className="text-foreground/80 hover:text-primary transition-colors"
            >
              Itinéraires
            </button>
            <button
              onClick={() => scrollToSection("map")}
              className="text-foreground/80 hover:text-primary transition-colors"
            >
              Carte
            </button>
          </div>

          {/* Mobile menu button */}
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <div className="md:hidden pb-4">
            <div className="flex flex-col gap-2">
              <button
                onClick={() => scrollToSection("about")}
                className="text-left px-4 py-2 text-foreground/80 hover:text-primary hover:bg-muted rounded-md transition-colors"
              >
                Histoire
              </button>
              <button
                onClick={() => scrollToSection("places")}
                className="text-left px-4 py-2 text-foreground/80 hover:text-primary hover:bg-muted rounded-md transition-colors"
              >
                Lieux
              </button>
              <button
                onClick={() => scrollToSection("itineraries")}
                className="text-left px-4 py-2 text-foreground/80 hover:text-primary hover:bg-muted rounded-md transition-colors"
              >
                Itinéraires
              </button>
              <button
                onClick={() => scrollToSection("map")}
                className="text-left px-4 py-2 text-foreground/80 hover:text-primary hover:bg-muted rounded-md transition-colors"
              >
                Carte
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
