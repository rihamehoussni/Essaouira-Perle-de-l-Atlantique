"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Star } from "lucide-react"

interface Place {
  id: string
  name: string
  description: string
  category: string
  duration: string
  rating: number
  lat: number
  lng: number
  image: string
}

const places: Place[] = [
  {
    id: "1",
    name: "La Médina",
    description:
      "Classée au patrimoine mondial de l'UNESCO, la médina d'Essaouira est un labyrinthe de ruelles étroites bordées de maisons blanches et bleues. Découvrez ses souks animés, ses artisans et son architecture unique.",
    category: "Patrimoine",
    duration: "3-4 heures",
    rating: 5,
    lat: 31.5125,
    lng: -9.77,
    image: "/essaouira-medina-blue-white-walls.jpg",
  },
  {
    id: "2",
    name: "Les Remparts",
    description:
      "Les fortifications impressionnantes d'Essaouira offrent des vues spectaculaires sur l'océan. La Skala de la Ville et la Skala du Port sont des sites incontournables pour admirer les canons portugais.",
    category: "Monument",
    duration: "2 heures",
    rating: 5,
    lat: 31.5135,
    lng: -9.772,
    image: "/essaouira-ramparts-cannons-ocean.jpg",
  },
  {
    id: "3",
    name: "Le Port",
    description:
      "Le port de pêche animé est le cœur battant d'Essaouira. Observez les pêcheurs ramener leur prise, les bateaux bleus traditionnels et dégustez du poisson frais grillé.",
    category: "Vie locale",
    duration: "1-2 heures",
    rating: 4,
    lat: 31.508,
    lng: -9.768,
    image: "/essaouira-fishing-port-blue-boats.jpg",
  },
  {
    id: "4",
    name: "Plage d'Essaouira",
    description:
      "Longue plage de sable fin parfaite pour le kitesurf et le windsurf grâce aux alizés constants. Promenez-vous au coucher du soleil pour un moment magique.",
    category: "Nature",
    duration: "2-3 heures",
    rating: 5,
    lat: 31.505,
    lng: -9.78,
    image: "/essaouira-beach-kitesurf-sunset.jpg",
  },
  {
    id: "5",
    name: "Île de Mogador",
    description:
      "Petite île en face du port, réserve naturelle protégée abritant le faucon d'Éléonore. Visible depuis les remparts, elle ajoute une touche mystérieuse au paysage.",
    category: "Nature",
    duration: "1 heure (vue)",
    rating: 4,
    lat: 31.495,
    lng: -9.79,
    image: "/mogador-island-essaouira-birds.jpg",
  },
  {
    id: "6",
    name: "Musée Sidi Mohammed ben Abdallah",
    description:
      "Installé dans un ancien riad, ce musée présente l'histoire locale, l'artisanat traditionnel et des collections d'instruments de musique gnaoua.",
    category: "Culture",
    duration: "1-2 heures",
    rating: 4,
    lat: 31.513,
    lng: -9.769,
    image: "/moroccan-museum-interior-traditional.jpg",
  },
]

export function Places() {
  const [selectedCategory, setSelectedCategory] = useState<string>("Tous")

  const categories = ["Tous", "Patrimoine", "Monument", "Vie locale", "Nature", "Culture"]

  const filteredPlaces =
    selectedCategory === "Tous" ? places : places.filter((place) => place.category === selectedCategory)

  return (
    <section id="places" className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4">Lieux à Visiter</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Explorez les sites emblématiques et les trésors cachés d'Essaouira
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              className="cursor-pointer px-4 py-2 text-sm hover:bg-primary hover:text-primary-foreground transition-colors"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Badge>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPlaces.map((place) => (
            <Card key={place.id} className="overflow-hidden hover:shadow-xl transition-shadow group">
              <div className="relative h-48 overflow-hidden">
                <div
                  className="w-full h-full bg-cover bg-center group-hover:scale-110 transition-transform duration-300"
                  style={{ backgroundImage: `url(${place.image})` }}
                />
                <div className="absolute top-4 right-4">
                  <Badge className="bg-accent text-accent-foreground">{place.category}</Badge>
                </div>
              </div>

              <div className="p-6">
                <h3 className="font-serif text-2xl font-bold mb-2 text-foreground">{place.name}</h3>

                <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{place.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-accent text-accent" />
                    <span>{place.rating}/5</span>
                  </div>
                </div>

                <p className="text-muted-foreground leading-relaxed mb-4">{place.description}</p>

                <div className="flex items-center gap-2 text-sm text-accent">
                  <MapPin className="w-4 h-4" />
                  <span>
                    {place.lat.toFixed(4)}, {place.lng.toFixed(4)}
                  </span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
