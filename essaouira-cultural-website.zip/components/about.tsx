import { Card } from "@/components/ui/card"
import { MapPin, Calendar, Users } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4">{"L'Histoire d'Essaouira"}</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Une cité millénaire au carrefour des civilisations
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <MapPin className="w-12 h-12 text-accent mb-4" />
            <h3 className="font-serif text-xl font-bold mb-2">Géographie</h3>
            <p className="text-muted-foreground leading-relaxed">
              Située sur la côte atlantique du Maroc, Essaouira bénéficie d'un climat tempéré et de vents constants qui
              en font un paradis pour les sports nautiques.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Calendar className="w-12 h-12 text-accent mb-4" />
            <h3 className="font-serif text-xl font-bold mb-2">Histoire</h3>
            <p className="text-muted-foreground leading-relaxed">
              Fondée au XVIIIe siècle, Essaouira était autrefois appelée Mogador. Sa médina fortifiée est inscrite au
              patrimoine mondial de l'UNESCO depuis 2001.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Users className="w-12 h-12 text-accent mb-4" />
            <h3 className="font-serif text-xl font-bold mb-2">Culture</h3>
            <p className="text-muted-foreground leading-relaxed">
              Carrefour de cultures berbère, arabe, africaine et européenne, Essaouira est célèbre pour son festival
              Gnaoua et ses artisans talentueux.
            </p>
          </Card>
        </div>

        <div className="prose prose-lg max-w-4xl mx-auto">
          <div className="bg-card p-8 rounded-lg shadow-md">
            <h3 className="font-serif text-2xl font-bold text-primary mb-4">{"Un Patrimoine d'Exception"}</h3>
            <p className="text-foreground/90 leading-relaxed mb-4">
              Essaouira, anciennement Mogador, est une ville portuaire fortifiée de la côte atlantique marocaine. Son
              architecture unique mêle influences européennes et nord-africaines, avec ses remparts imposants, ses
              ruelles étroites et ses maisons blanches et bleues caractéristiques.
            </p>
            <p className="text-foreground/90 leading-relaxed mb-4">
              La ville a été un important centre commercial depuis l'Antiquité, servant de pont entre l'Afrique
              subsaharienne et l'Europe. Les Phéniciens, les Romains et les Portugais y ont tous laissé leur empreinte
              avant que le sultan Sidi Mohammed ben Abdallah ne reconstruise la ville au XVIIIe siècle.
            </p>
            <p className="text-foreground/90 leading-relaxed">
              Aujourd'hui, Essaouira est reconnue pour son ambiance décontractée, sa scène artistique vibrante et son
              authenticité préservée. Elle attire artistes, surfeurs et voyageurs en quête d'une expérience marocaine
              unique, loin de l'agitation des grandes villes.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
