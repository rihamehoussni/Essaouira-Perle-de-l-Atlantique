import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Places } from "@/components/places"
import { Itineraries } from "@/components/itineraries"
import { InteractiveMap } from "@/components/interactive-map"
import { Footer } from "@/components/footer"
import { Navigation } from "@/components/navigation"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <About />
      <Places />
      <Itineraries />
      <InteractiveMap />
      <Footer />
    </div>
  )
}
